#!/usr/bin/env python3
"""
render_core.py — Resolution-Agnostic Vector Rendering Engine for Faceless Video Production
Supports native 4K UHD (3840x2160 @ 60 FPS) and 1080p with zero-resize overscan camera push-in,
cinematic obsidian atmospheric backgrounds, and dynamic karaoke word-pop Shorts captions.
"""

import os
import math
import time
from dataclasses import dataclass
from functools import lru_cache
from typing import Tuple, Optional, List, Dict, Any
import numpy as np
from PIL import Image, ImageDraw, ImageFont, ImageFilter

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
REPO_ROOT = os.path.abspath(os.path.join(SCRIPT_DIR, ".."))

# Locate Inter Display Bold
FONT_PATHS = [
    os.path.join(REPO_ROOT, "fonts", "InterDisplay-Bold.otf"),
    "fonts/InterDisplay-Bold.otf",
    os.path.expanduser("~/Library/Fonts/InterDisplay-Bold.otf"),
    "/usr/share/fonts/opentype/inter/InterDisplay-Bold.otf"
]
FB = next((fp for fp in FONT_PATHS if os.path.exists(fp)), os.path.join(REPO_ROOT, "fonts", "InterDisplay-Bold.otf"))


@dataclass(frozen=True)
class ResolutionProfile:
    name: str
    width: int
    height: int
    fps: int
    scale: float
    subtitle_y: int
    content_max_y: int
    subtitle_fontsize: int
    subtitle_stroke: int
    grid_size: int
    watermark_pos: Tuple[int, int]
    watermark_size: int

    @property
    def is_vertical(self) -> bool:
        return self.height > self.width

    @property
    def frame_time(self) -> float:
        return 1.0 / self.fps


# Standard Profiles
PROFILE_4K60 = ResolutionProfile(
    name="4K60_HORIZONTAL",
    width=3840,
    height=2160,
    fps=60,
    scale=2.0,
    subtitle_y=2020,
    content_max_y=1830,
    subtitle_fontsize=80,
    subtitle_stroke=10,
    grid_size=180,
    watermark_pos=(140, 110),
    watermark_size=72
)

PROFILE_4K60_VERTICAL = ResolutionProfile(
    name="4K60_VERTICAL",
    width=2160,
    height=3840,
    fps=60,
    scale=2.0,
    subtitle_y=3120,
    content_max_y=2800,
    subtitle_fontsize=132,
    subtitle_stroke=16,
    grid_size=180,
    watermark_pos=(1080, 260),
    watermark_size=72
)

PROFILE_1080P30 = ResolutionProfile(
    name="1080P30_HORIZONTAL",
    width=1920,
    height=1080,
    fps=30,
    scale=1.0,
    subtitle_y=1010,
    content_max_y=915,
    subtitle_fontsize=40,
    subtitle_stroke=5,
    grid_size=90,
    watermark_pos=(70, 55),
    watermark_size=36
)

PROFILE_1080P30_VERTICAL = ResolutionProfile(
    name="1080P30_VERTICAL",
    width=1080,
    height=1920,
    fps=30,
    scale=1.0,
    subtitle_y=1560,
    content_max_y=1400,
    subtitle_fontsize=66,
    subtitle_stroke=8,
    grid_size=90,
    watermark_pos=(540, 130),
    watermark_size=36
)

PROFILES = {
    "4k60": PROFILE_4K60,
    "4k60_vert": PROFILE_4K60_VERTICAL,
    "1080p30": PROFILE_1080P30,
    "1080p30_vert": PROFILE_1080P30_VERTICAL,
}


@lru_cache(maxsize=128)
def get_font(size: int, path: str = FB) -> ImageFont.FreeTypeFont:
    """Cached font loader with graceful fallback."""
    try:
        return ImageFont.truetype(path, max(int(size), 1))
    except Exception:
        return ImageFont.load_default()


# Color Palette
WHITE       = (255, 255, 255)
DIM         = (185, 192, 225)
SLATE       = (100, 110, 140)
DARK_CARD   = (16, 20, 36)
CARD_BORDER = (255, 255, 255, 30)

CYAN        = (70, 220, 255)
PURPLE      = (150, 110, 255)
YELLOW      = (255, 205, 70)
GREEN       = (90, 235, 150)
RED         = (255, 70, 90)
SUB_RED     = (255, 30, 50)
SUB_GREEN   = (35, 195, 110)

PALETTE = {
    "white": WHITE, "dim": DIM, "slate": SLATE,
    "cyan": CYAN, "purple": PURPLE, "yellow": YELLOW,
    "green": GREEN, "red": RED, "sub_red": SUB_RED, "sub_green": SUB_GREEN
}


def create_cinematic_background(width: int, height: int, is_vertical: bool = False) -> Image.Image:
    """Wrapper for obsidian atmospheric background for backward compatibility."""
    return create_thematic_background(width, height, theme="obsidian", is_vertical=is_vertical)


def create_thematic_background(
    width: int,
    height: int,
    theme: str = "obsidian",
    is_vertical: bool = False,
    accent: Optional[Tuple[int, int, int]] = None
) -> Image.Image:
    """
    Generates rich, bespoke thematic backgrounds tailored to the video topic:
    - 'obsidian': Cinematic obsidian atmospheric with ambient spotlights and film grain
    - 'blueprint': Technical architectural grid with gradient and intersection crosshairs
    - 'silicon': Silicon interposer / PCB micro-grid traces for hardware, GPU, and VRAM topics
    - 'terminal': CRT scanline / phosphor matrix console atmosphere for dev tools & security
    - 'studio': Smooth diffuse radial midnight gradient for modern SaaS & engineering overviews
    - 'minimal': Ultra-clean graphite matte canvas with subtle geometric framing
    """
    t_lower = theme.lower().strip()
    y_grid, x_grid = np.ogrid[:height, :width]
    rng = np.random.default_rng(42)

    if t_lower == "blueprint":
        # 1. Blueprint Architecture Gradient
        top_c = np.array([8.0, 12.0, 28.0], dtype=np.float32)
        bot_c = np.array([24.0, 16.0, 52.0], dtype=np.float32)
        grad_factor = (y_grid / max(height - 1, 1)).astype(np.float32)
        comp = np.zeros((height, width, 3), dtype=np.float32)
        comp[:, :] = top_c * (1.0 - grad_factor[:, :, None]) + bot_c * grad_factor[:, :, None]

        # Ambient soft center spotlight
        cx, cy = width * 0.5, height * 0.45
        d_sq = ((x_grid - cx) / (width * 0.45))**2 + ((y_grid - cy) / (height * 0.45))**2
        comp += np.exp(-d_sq * 1.8)[:, :, None] * np.array([18.0, 28.0, 55.0], dtype=np.float32)

        # Film Grain & Vignette
        comp += rng.normal(0.0, 2.8, (height, width, 1)).astype(np.float32)
        vx = ((x_grid - width * 0.5) / (width * 0.5))**2
        vy = ((y_grid - height * 0.5) / (height * 0.5))**2
        comp *= (1.0 - 0.20 * np.clip(vx + vy, 0.0, 1.0)[:, :, None])

        img = Image.fromarray(np.clip(comp, 0, 255).astype(np.uint8), "RGB")
        d = ImageDraw.Draw(img)

        # Blueprint Technical Grid
        grid_step = 90 if not is_vertical else 100
        grid_col = (26, 38, 70)
        for x in range(0, width, grid_step):
            d.line([(x, 0), (x, height)], fill=grid_col, width=1)
        for y in range(0, height, grid_step):
            d.line([(0, y), (width, y)], fill=grid_col, width=1)

        # Crosshairs at intersections
        for x in range(grid_step * 2, width, grid_step * 3):
            for y in range(grid_step * 2, height, grid_step * 3):
                d.line([(x - 4, y), (x + 4, y)], fill=(45, 65, 110), width=1)
                d.line([(x, y - 4), (x, y + 4)], fill=(45, 65, 110), width=1)

        return img

    elif t_lower == "silicon":
        # Silicon Interposer / Chip Hardware Theme
        base_c = np.array([11.0, 13.0, 20.0], dtype=np.float32)
        comp = np.zeros((height, width, 3), dtype=np.float32) + base_c

        # Sapphire & Copper ambient pools
        cx1, cy1 = width * 0.3, height * 0.3
        d1 = ((x_grid - cx1) / (width * 0.4))**2 + ((y_grid - cy1) / (height * 0.4))**2
        comp += np.exp(-d1 * 1.5)[:, :, None] * np.array([20.0, 35.0, 65.0], dtype=np.float32)

        cx2, cy2 = width * 0.7, height * 0.7
        d2 = ((x_grid - cx2) / (width * 0.4))**2 + ((y_grid - cy2) / (height * 0.4))**2
        comp += np.exp(-d2 * 1.5)[:, :, None] * np.array([45.0, 25.0, 20.0], dtype=np.float32)

        comp += rng.normal(0.0, 2.5, (height, width, 1)).astype(np.float32)
        vx = ((x_grid - width * 0.5) / (width * 0.5))**2
        vy = ((y_grid - height * 0.5) / (height * 0.5))**2
        comp *= (1.0 - 0.22 * np.clip(vx + vy, 0.0, 1.0)[:, :, None])

        img = Image.fromarray(np.clip(comp, 0, 255).astype(np.uint8), "RGB")
        d = ImageDraw.Draw(img)

        # PCB / Bus lane trace lines
        trace_step = 120
        for x in range(trace_step // 2, width, trace_step):
            d.line([(x, 0), (x, height)], fill=(22, 28, 42), width=1)
        for y in range(trace_step // 2, height, trace_step):
            d.line([(0, y), (width, y)], fill=(22, 28, 42), width=1)

        # Pin pads
        for x in range(trace_step // 2, width, trace_step * 2):
            for y in range(trace_step // 2, height, trace_step * 2):
                d.rectangle([x - 2, y - 2, x + 2, y + 2], fill=(50, 60, 85))

        return img

    elif t_lower == "terminal":
        # CRT Terminal / Dark Phosphor Theme
        base_c = np.array([8.0, 14.0, 12.0], dtype=np.float32)
        comp = np.zeros((height, width, 3), dtype=np.float32) + base_c

        # Soft emerald ambient center
        cx, cy = width * 0.5, height * 0.4
        d_sq = ((x_grid - cx) / (width * 0.5))**2 + ((y_grid - cy) / (height * 0.5))**2
        comp += np.exp(-d_sq * 1.6)[:, :, None] * np.array([12.0, 32.0, 20.0], dtype=np.float32)

        comp += rng.normal(0.0, 3.0, (height, width, 1)).astype(np.float32)
        vx = ((x_grid - width * 0.5) / (width * 0.5))**2
        vy = ((y_grid - height * 0.5) / (height * 0.5))**2
        comp *= (1.0 - 0.25 * np.clip(vx + vy, 0.0, 1.0)[:, :, None])

        img = Image.fromarray(np.clip(comp, 0, 255).astype(np.uint8), "RGB")
        d = ImageDraw.Draw(img)

        # Scanlines
        scan_step = 6
        for y in range(0, height, scan_step):
            d.line([(0, y), (width, y)], fill=(12, 18, 15), width=1)

        return img

    elif t_lower == "studio":
        # Clean Studio Radial Gradient
        base_c = np.array([10.0, 14.0, 24.0], dtype=np.float32)
        comp = np.zeros((height, width, 3), dtype=np.float32) + base_c

        cx, cy = width * 0.5, height * 0.42
        d_sq = ((x_grid - cx) / (width * 0.55))**2 + ((y_grid - cy) / (height * 0.55))**2
        comp += np.exp(-d_sq * 1.4)[:, :, None] * np.array([28.0, 36.0, 64.0], dtype=np.float32)

        comp += rng.normal(0.0, 2.2, (height, width, 1)).astype(np.float32)
        vx = ((x_grid - width * 0.5) / (width * 0.5))**2
        vy = ((y_grid - height * 0.5) / (height * 0.5))**2
        comp *= (1.0 - 0.18 * np.clip(vx + vy, 0.0, 1.0)[:, :, None])

        return Image.fromarray(np.clip(comp, 0, 255).astype(np.uint8), "RGB")

    elif t_lower == "minimal":
        # Minimalist Deep Graphite
        base_c = np.array([15.0, 16.0, 20.0], dtype=np.float32)
        comp = np.zeros((height, width, 3), dtype=np.float32) + base_c
        comp += rng.normal(0.0, 2.0, (height, width, 1)).astype(np.float32)

        img = Image.fromarray(np.clip(comp, 0, 255).astype(np.uint8), "RGB")
        d = ImageDraw.Draw(img)
        # Subtle perimeter frame guide
        pad = 60
        d.rectangle([pad, pad, width - pad, height - pad], outline=(28, 30, 38), width=1)
        return img

    else:
        # Default: Cinematic Obsidian Atmospheric
        base = np.zeros((height, width, 3), dtype=np.float32)
        base[:, :] = [10.0, 13.0, 20.0]

        cx1, cy1 = (width * 0.25, height * 0.22) if is_vertical else (width * 0.22, height * 0.25)
        rx1, ry1 = (width * 0.45, height * 0.35) if is_vertical else (width * 0.40, height * 0.45)
        d1_sq = ((x_grid - cx1) / rx1)**2 + ((y_grid - cy1) / ry1)**2
        spot1 = np.exp(-d1_sq * 1.5)[:, :, None] * np.array([24.0, 38.0, 75.0], dtype=np.float32)

        cx2, cy2 = (width * 0.75, height * 0.75) if is_vertical else (width * 0.78, height * 0.75)
        rx2, ry2 = (width * 0.45, height * 0.35) if is_vertical else (width * 0.40, height * 0.45)
        d2_sq = ((x_grid - cx2) / rx2)**2 + ((y_grid - cy2) / ry2)**2
        spot2 = np.exp(-d2_sq * 1.5)[:, :, None] * np.array([38.0, 24.0, 68.0], dtype=np.float32)

        comp = base + spot1 + spot2
        comp += rng.normal(0.0, 3.2, (height, width, 1)).astype(np.float32)

        vx = ((x_grid - width * 0.5) / (width * 0.5))**2
        vy = ((y_grid - height * 0.5) / (height * 0.5))**2
        vignette = 1.0 - 0.22 * np.clip(vx + vy, 0.0, 1.0)[:, :, None]
        comp *= vignette

        final_arr = np.clip(comp, 0, 255).astype(np.uint8)
        img = Image.fromarray(final_arr, "RGB")
        d = ImageDraw.Draw(img)

        matrix_step = 140 if is_vertical else 160
        matrix_color = (45, 58, 85)
        for x in range(matrix_step // 2, width, matrix_step):
            for y in range(matrix_step // 2, height, matrix_step):
                d.rectangle([x - 1, y - 1, x + 1, y + 1], fill=matrix_color)

        return img


_BG_CACHE: Dict[Tuple[int, int, bool, str], Image.Image] = {}

def get_cached_background(width: int, height: int, is_vertical: bool = False, theme: str = "obsidian") -> Image.Image:
    key = (width, height, is_vertical, theme.lower())
    if key not in _BG_CACHE:
        _BG_CACHE[key] = create_thematic_background(width, height, theme=theme, is_vertical=is_vertical)
    return _BG_CACHE[key].copy()


class OverscanCanvas:
    """
    Dynamic Overscan Canvas:
    Allocates at 1.035x overscan margin.
    Slices exact width x height crops directly on each frame with organic drift,
    achieving 120+ FPS throughput by eliminating CPU resize overhead.
    """
    def __init__(self, profile: ResolutionProfile, overscan: float = 0.035, theme: str = "obsidian", custom_bg: Optional[Image.Image] = None):
        self.profile = profile
        self.overscan = overscan
        self.theme = theme
        self.W = profile.width
        self.H = profile.height
        self.ov_w = int(round(self.W * (1.0 + overscan)))
        self.ov_h = int(round(self.H * (1.0 + overscan)))
        self.margin_x = (self.ov_w - self.W) / 2.0
        self.margin_y = (self.ov_h - self.H) / 2.0
        self.scale = profile.scale

        # Base canvas
        if custom_bg is not None:
            self.bg = custom_bg.copy()
        else:
            self.bg = get_cached_background(self.ov_w, self.ov_h, is_vertical=profile.is_vertical, theme=theme)
        self.frame = self.bg.copy()
        self.draw = ImageDraw.Draw(self.frame)

    def reset(self):
        """Reset frame to pristine background."""
        self.frame = self.bg.copy()
        self.draw = ImageDraw.Draw(self.frame)

    def to_canvas(self, x: float, y: float) -> Tuple[float, float]:
        """Maps base coordinate to overscan canvas space."""
        return (self.margin_x + x * self.scale, self.margin_y + y * self.scale)

    def draw_card(self, box: Tuple[float, float, float, float], radius: float = 16,
                  fill=DARK_CARD, outline=CARD_BORDER, width: int = 2):
        """Draws rounded card in base coordinates."""
        x0, y0 = self.to_canvas(box[0], box[1])
        x1, y1 = self.to_canvas(box[2], box[3])
        r = radius * self.scale
        w = max(1, int(round(width * (self.scale / 2.0))))
        self.draw.rounded_rectangle([x0, y0, x1, y1], radius=r, fill=fill, outline=outline, width=w)

    def draw_text(self, xy: Tuple[float, float], text: str, size: int,
                  fill=WHITE, anchor="la", stroke_width: int = 0, stroke_fill=(0, 0, 0)):
        """Draws crisp scaled typography."""
        cx, cy = self.to_canvas(xy[0], xy[1])
        font = get_font(int(size * self.scale))
        sw = int(round(stroke_width * self.scale))
        self.draw.text((cx, cy), text, font=font, fill=fill, anchor=anchor,
                       stroke_width=sw, stroke_fill=stroke_fill if sw > 0 else None)

    def draw_pill(self, xy: Tuple[float, float], text: str, size: int = 20,
                  text_color=WHITE, bg_color=(30, 36, 56), outline_color=None,
                  pad: Tuple[int, int] = (16, 6), radius: int = 12):
        """Draws a rounded badge/pill."""
        font = get_font(int(size * self.scale))
        tlen = self.draw.textlength(text, font=font)
        h = font.size
        cx, cy = self.to_canvas(xy[0], xy[1])
        px, py = pad[0] * self.scale, pad[1] * self.scale
        box = [cx - px, cy - py, cx + tlen + px, cy + h + py]
        w = max(1, int(round(1 * self.scale))) if outline_color else 0
        self.draw.rounded_rectangle(box, radius=radius * self.scale, fill=bg_color,
                                    outline=outline_color, width=w)
        self.draw.text((cx, cy), text, font=font, fill=text_color)

    def slice_frame(self, p_scene: float, drift_amp: float = 8.0) -> Image.Image:
        """
        Zero-Resize Camera Drift Crop:
        Takes a direct crop slice from the overscan canvas.
        Zero pixel resizing = 120+ FPS throughput.
        """
        p = max(0.0, min(1.0, p_scene))
        dx = drift_amp * (math.sin(0.7 * p * 6.28) + 0.5 * math.sin(1.9 * p * 6.28))
        dy = (drift_amp * 0.6) * (math.sin(0.6 * p * 6.28) + 0.5 * math.sin(1.7 * p * 6.28))
        
        zoom_offset_x = (self.margin_x * 0.5) * p
        zoom_offset_y = (self.margin_y * 0.5) * p

        x0 = int(round(self.margin_x - zoom_offset_x + dx))
        y0 = int(round(self.margin_y - zoom_offset_y + dy))

        x0 = max(0, min(self.ov_w - self.W, x0))
        y0 = max(0, min(self.ov_h - self.H, y0))

        return self.frame.crop((x0, y0, x0 + self.W, y0 + self.H))


# -----------------------------------------------------------------------------
# Declarative Scene Components
# -----------------------------------------------------------------------------

def clamp(x: float, lo: float = 0.0, hi: float = 1.0) -> float:
    return max(lo, min(hi, x))

def ease_out_quart(x: float) -> float:
    x = clamp(x)
    return 1.0 - (1.0 - x) ** 4

def ease_in_out(x: float) -> float:
    x = clamp(x)
    return x * x * (3.0 - 2.0 * x)

def smooth_float(t: float, freq: float = 1.4, amp: float = 3.5, phase: float = 0.0) -> float:
    return amp * math.sin(t * freq * 2.0 * math.pi + phase)

def spring(t: float, freq: float = 2.2, zeta: float = 0.72) -> float:
    """Natural spring physics curve with ~4% overshoot. Settles in ~0.5s."""
    if t <= 0.0:
        return 0.0
    w = 2.0 * math.pi * freq
    wd = w * math.sqrt(1.0 - zeta ** 2)
    return 1.0 - math.exp(-zeta * w * t) * (math.cos(wd * t) + zeta * w / wd * math.sin(wd * t))

def bezier_point(p0: Tuple[float, float], p1: Tuple[float, float], p2: Tuple[float, float], t: float) -> Tuple[float, float]:
    """Quadratic Bezier curve point."""
    u = 1.0 - t
    x = u * u * p0[0] + 2.0 * u * t * p1[0] + t * t * p2[0]
    y = u * u * p0[1] + 2.0 * u * t * p1[1] + t * t * p2[1]
    return (x, y)

def draw_cursor(dr: ImageDraw.Draw, pos: Tuple[float, float], scale: float = 1.0):
    """Draws an authentic mouse cursor."""
    x, y = pos
    s = scale
    pts = [
        (x, y), (x, y + 28 * s), (x + 8 * s, y + 21 * s),
        (x + 14 * s, y + 33 * s), (x + 19 * s, y + 30 * s),
        (x + 13 * s, y + 19 * s), (x + 23 * s, y + 19 * s)
    ]
    dr.polygon(pts, fill=(255, 255, 255), outline=(15, 20, 30))

def render_real_asset_frame(
    canvas: OverscanCanvas,
    asset_img: Image.Image,
    rel_t: float,
    box: Optional[Tuple[float, float, float, float]] = None
):
    """
    Pastes a genuine UI screen capture (VS Code, Terminal, Website) onto the canvas
    with realistic shadow, rounded corners, and spring scale entrance.
    Handles both 16:9 horizontal and 9:16 vertical safe boundaries.
    """
    p_enter = min(1.0, spring(rel_t * 1.5))
    if box is None:
        if canvas.profile.is_vertical:
            # 9:16 Vertical Shorts safe framing: 92% width, vertically centered above captions
            max_w = int(canvas.W * 0.92)
            aspect = asset_img.height / float(asset_img.width)
            w = max_w
            h = min(int(w * aspect), int(canvas.profile.content_max_y * 0.65))
            cx = (canvas.W - w) // 2
            cy = int(canvas.H * 0.38) - (h // 2)
            box = (cx, cy, cx + w, cy + h)
        else:
            # 16:9 Horizontal Widescreen safe framing
            w = min(1500, int(asset_img.width / canvas.scale))
            aspect = asset_img.height / float(asset_img.width)
            h = min(int(w * aspect), 680)
            cx = (canvas.W - w) // 2
            cy = (canvas.profile.content_max_y - h) // 2 + 50
            box = (cx, cy, cx + w, cy + h)

    x0, y0 = canvas.to_canvas(box[0], box[1])
    target_w = int((box[2] - box[0]) * canvas.scale)
    target_h = int((box[3] - box[1]) * canvas.scale)

    # Scale asset to fit target box
    resized = asset_img.resize((target_w, target_h), Image.Resampling.LANCZOS)
    canvas.frame.paste(resized, (int(x0), int(y0)), resized if resized.mode == "RGBA" else None)

def render_brand_card(
    canvas: OverscanCanvas,
    channel_name: str,
    tagline: str,
    badge: str,
    rel_t: float,
    logo_img: Optional[Image.Image] = None
):
    """
    Renders the official Master Brand Intro card (Matches stop_paying_for_ai_local_llms).
    Concentric tech glow rings, official channel logo or badge, bold channel name, and tagline.
    """
    sc = canvas.scale
    cx = canvas.W // 2
    cy_ring = int(320 * sc) if not canvas.profile.is_vertical else int(520 * sc)
    
    s = ease_out_quart(min(1.0, rel_t / 0.6))
    r = int(140 * sc * s)
    flt = smooth_float(rel_t, freq=1.6, amp=4.0 * sc)
    
    rcx, rcy = canvas.to_canvas(cx, cy_ring)
    
    # Concentric Tech Glow Rings
    canvas.draw.ellipse([rcx - r - int(8*sc), rcy - r - int(8*sc), rcx + r + int(8*sc), rcy + r + int(8*sc)], fill=(30, 16, 70), outline=CYAN, width=max(1, int(2 * sc)))
    canvas.draw.ellipse([rcx - r, rcy - r, rcx + r, rcy + r], fill=PURPLE)
    r2 = max(1, r - int(18 * sc))
    canvas.draw.ellipse([rcx - r2, rcy - r2, rcx + r2, rcy + r2], fill=(16, 12, 38))
    
    # Official Logo or Badge in center of ring
    if logo_img and s > 0.4:
        logo_sz = int(185 * sc * s)
        res_logo = logo_img.resize((logo_sz, logo_sz), Image.Resampling.LANCZOS)
        lx, ly = canvas.to_canvas(cx - int(logo_sz / 2), cy_ring - int(logo_sz / 2) + int(flt))
        canvas.frame.paste(res_logo, (int(lx), int(ly)), res_logo)
    elif s > 0.6:
        canvas.draw_text((cx, cy_ring + int(flt)), badge, size=int(84 * sc * s), fill=WHITE, anchor="mm")
        
    name_y = cy_ring + int(250 * sc) if not canvas.profile.is_vertical else cy_ring + int(320 * sc)
    tag_y = name_y + int(105 * sc) if not canvas.profile.is_vertical else name_y + int(85 * sc)
    canvas.draw_text((cx, name_y), channel_name, size=int(130 * sc), fill=WHITE, anchor="mm")
    canvas.draw_text((cx, tag_y), tagline, size=int(46 * sc), fill=CYAN, anchor="mm")

def render_outro_card(
    canvas: OverscanCanvas,
    channel_name: str,
    tagline: str,
    rel_t: float,
    duration: float = 7.0,
    logo_img: Optional[Image.Image] = None,
    click_time: float = 3.8
):
    """
    Renders the official Master Outro conversion card (Matches stop_paying_for_ai_local_llms).
    Bold channel name, tagline, massive Subscribe button converting red->green with Bezier cursor click.
    """
    sc = canvas.scale
    cx = canvas.W // 2
    flt = smooth_float(rel_t, freq=1.5, amp=3.5 * sc)
    
    name_y = int(280 * sc) if not canvas.profile.is_vertical else int(420 * sc)
    tag_y = name_y + int(110 * sc)
    btn_y = tag_y + int(210 * sc)
    
    canvas.draw_text((cx, name_y), channel_name, size=int(140 * sc), fill=WHITE, anchor="mm")
    canvas.draw_text((cx, tag_y), tagline, size=int(46 * sc), fill=CYAN, anchor="mm")
    
    # Dynamic Subscribe Button: Red -> Green transition
    btn_w = int(740 * sc)
    btn_h = int(160 * sc)
    is_subscribed = (rel_t >= (click_time + 0.2))
    
    if (click_time - 0.1) <= rel_t <= (click_time + 0.3):
        press_s = 0.95 + 0.05 * math.sin((rel_t - (click_time - 0.1)) / 0.4 * math.pi)
    else:
        press_s = 1.0 + (0.02 * math.sin(rel_t * 6.0) if is_subscribed else 0.0)
        
    cur_w = int(btn_w * press_s)
    cur_h = int(btn_h * press_s)
    
    btn_color = (35, 195, 110) if is_subscribed else (255, 30, 50)
    btn_text = "✓ SUBSCRIBED!" if is_subscribed else "SUBSCRIBE"
    
    canvas.draw_card((cx - cur_w // 2, btn_y - cur_h // 2, cx + cur_w // 2, btn_y + cur_h // 2), radius=cur_h // 2, fill=btn_color)
    canvas.draw_text((cx, btn_y), btn_text, size=int(84 * sc), fill=WHITE, anchor="mm")
    
    # Animated Cursor Glide and Click
    p0 = (int(1650 * sc), int(950 * sc))
    p1 = (int(1350 * sc), int(650 * sc))
    p2 = (cx + int(30 * sc), btn_y + int(10 * sc))
    
    if 1.0 <= rel_t <= click_time:
        p_cursor = ease_in_out((rel_t - 1.0) / max(0.1, click_time - 1.0))
        cur_pos = bezier_point(p0, p1, p2, p_cursor)
        cx_draw, cy_draw = canvas.to_canvas(*cur_pos)
        draw_cursor(canvas.draw, (cx_draw, cy_draw), scale=sc)
    elif click_time < rel_t <= (click_time + 0.6):
        click_p = (rel_t - click_time) / 0.6
        cx_draw, cy_draw = canvas.to_canvas(*p2)
        draw_cursor(canvas.draw, (cx_draw, cy_draw), scale=sc)
        # Expanding gold shockwave ripple ring
        rip_r = int(120 * sc * click_p)
        alpha = int(255 * (1.0 - click_p))
        canvas.draw.ellipse([cx_draw - rip_r, cy_draw - rip_r, cx_draw + rip_r, cy_draw + rip_r], outline=(255, 205, 70, alpha), width=max(2, int(4 * sc)))
    elif (click_time + 0.6) < rel_t <= duration:
        p_exit = ease_out_quart((rel_t - (click_time + 0.6)) / max(0.1, duration - (click_time + 0.6)))
        exit_pos = bezier_point(p2, (cx + int(200 * sc), btn_y + int(150 * sc)), (int(1600 * sc), int(950 * sc)), p_exit)
        cx_draw, cy_draw = canvas.to_canvas(*exit_pos)
        draw_cursor(canvas.draw, (cx_draw, cy_draw), scale=sc)
        
    callout_y = btn_y + int(150 * sc)
    canvas.draw_text((cx, callout_y + int(flt)), "Drop your thoughts in the comments below! 👇", size=int(34 * sc), fill=YELLOW, anchor="mm")


def render_subtitles(img: Image.Image, text: str, profile: ResolutionProfile):
    """Draws burned-in standard subtitles at the designated safe zone."""
    if not text:
        return
    d = ImageDraw.Draw(img)
    font = get_font(profile.subtitle_fontsize)
    xy = (profile.width / 2.0, profile.subtitle_y)
    d.text(xy, text.upper(), font=font, fill=WHITE, anchor="mm",
           stroke_width=profile.subtitle_stroke, stroke_fill=(0, 0, 0))


def render_karaoke_shorts(
    img: Image.Image,
    words: List[Tuple[str, float, float]],
    t: float,
    profile: ResolutionProfile,
    active_color=YELLOW,
    base_color=WHITE
):
    """
    Dynamic Karaoke Shorts Captions:
    - Renders 3-4 word chunks centered at profile.subtitle_y.
    - Active word illuminates in active_color (Electric Yellow or Cyan) with a subtle 1.06x scale bounce.
    - Inactive words remain crisp pure white with heavy black stroke.
    """
    if not words:
        return
    d = ImageDraw.Draw(img)
    font_base = get_font(profile.subtitle_fontsize)
    font_bounce = get_font(int(profile.subtitle_fontsize * 1.06))

    # Calculate total chunk width
    word_widths = []
    for w, a, b in words:
        is_active = (a <= t < b)
        font = font_bounce if is_active else font_base
        wd = d.textlength(w.upper() + " ", font=font)
        word_widths.append((w, a, b, wd, font, is_active))

    tot_w = sum(ww[3] for ww in word_widths)
    start_x = (profile.width - tot_w) / 2.0
    cy = profile.subtitle_y

    cur_x = start_x
    for w, a, b, wd, font, is_active in word_widths:
        fill_col = active_color if is_active else base_color
        d.text(
            (cur_x, cy),
            w.upper(),
            font=font,
            fill=fill_col,
            anchor="lm",
            stroke_width=profile.subtitle_stroke,
            stroke_fill=(0, 0, 0)
        )
        cur_x += wd


def render_watermark(img: Image.Image, channel_name: str, profile: ResolutionProfile):
    """Draws fixed channel watermark in safe zone."""
    d = ImageDraw.Draw(img)
    font = get_font(profile.watermark_size)
    anchor = "mm" if profile.is_vertical else "lm"
    d.text(profile.watermark_pos, channel_name, font=font, fill=(160, 170, 210), anchor=anchor)
